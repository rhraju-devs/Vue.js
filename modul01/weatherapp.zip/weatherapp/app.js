// const apiKey = '7f6b2b2901ccfdb82bda76d2ef1024c7';


    // document.addEventListener('DOMContentLoaded', function() {
    //     const apiKey = '7f6b2b2901ccfdb82bda76d2ef1024c7';
        
    //     const searchButton = document.getElementById('search-button');
    //     const cityInput = document.getElementById('city-input');
    //     const weatherInfo = document.getElementById('weather-info');
      
    //     searchButton.addEventListener('click', function() {
    //       const city = cityInput.value;
          
    //       // Make a request to OpenWeatherMap API
    //       fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`)
    //         .then(response => response.json())
    //         .then(data => {
    //           // Extract relevant weather information
    //           const temperature = data.main.temp;
    //           const weatherDescription = data.weather[0].description;
    //           const humidity = data.main.humidity;
    //           const pressure = data.main.pressure;
    //           const tempMin = data.main.temp_min;
    //           const tempMax = data.main.temp_max;
    //           const windSpeed = data.wind.speed;
    //           const clouds = data.clouds.all;
              
    //           // Display the weather information
    //           weatherInfo.innerHTML = `
    //             <h2>${city}</h2>
    //             <p>Temperature: ${temperature}°C</p>
    //             <p>Weather: ${weatherDescription}</p>
    //             <p>Humidity: ${humidity}%</p>
    //             <p>Pressure: ${pressure} hPa</p>
    //             <p>Min Temperature: ${tempMin}°C</p>
    //             <p>Max Temperature: ${tempMax}°C</p>
    //             <p>Wind Speed: ${windSpeed} m/s</p>
    //             <p>Clouds: ${clouds}%</p>
    //           `;
    //         })
    //         .catch(error => {
    //           console.log('Error:', error);
    //           weatherInfo.innerHTML = 'Error fetching weather data.';
    //         });
    //     });
    //   });
      


    document.addEventListener('DOMContentLoaded', function() {
        const apiKey = '7f6b2b2901ccfdb82bda76d2ef1024c7';
      
        const searchButton = document.getElementById('search-button');
        const cityInput = document.getElementById('city-input');
        const weatherInfo = document.getElementById('weather-info');
      
        const searchWeather = function() {
          const city = cityInput.value;
      
          // Make a request to OpenWeatherMap API
          fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`)
            .then(response => response.json())
            .then(data => {
              // Extract relevant weather information
              const temperature = data.main.temp;
              const weatherDescription = data.weather[0].description;
              const humidity = data.main.humidity;
              const pressure = data.main.pressure;
              const tempMin = data.main.temp_min;
              const tempMax = data.main.temp_max;
              const windSpeed = data.wind.speed;
              const clouds = data.clouds.all;
      
              // Display the weather information
              weatherInfo.innerHTML = `
                <h2>${city}</h2>
                <p>Temperature: ${temperature}°C</p>
                <p>Weather: ${weatherDescription}</p>
                <p>Humidity: ${humidity}%</p>
                <p>Pressure: ${pressure} hPa</p>
                <p>Min Temperature: ${tempMin}°C</p>
                <p>Max Temperature: ${tempMax}°C</p>
                <p>Wind Speed: ${windSpeed} m/s</p>
                <p>Clouds: ${clouds}%</p>
              `;
            })
            .catch(error => {
              console.log('Error:', error);
              weatherInfo.innerHTML = 'Error fetching weather data.';
            });
        };
      
        searchButton.addEventListener('click', searchWeather);
      
        cityInput.addEventListener('keydown', function(event) {
          if (event.key === 'Enter') {
            searchWeather();
          }
        });
      });
      
  